from langchain.embeddings import AzureOpenAIEmbeddings
from azure.core.credentials import AzureKeyCredential
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex,
    SearchField,
    SearchFieldDataType,
    SimpleField,
    SearchableField,
    VectorSearch,
    VectorSearchProfile,
    HnswAlgorithmConfiguration,
    SearchIndexerDataContainer,
    SearchIndexerDataSourceConnection
)
import os
from langchain.text_splitter import CharacterTextSplitter
from azure.search.documents import SearchClient, SearchItemPaged
import uuid
from pathlib import Path
from dotenv import load_dotenv
from ..utils.document_loaders import load_document, strings_to_documents
from .qna_manager import QnAManager
import traceback
from typing import Dict 


# Load environment variables from the .env file
load_dotenv()

class KnowledgeBaseManager:
    def __init__(self, azure_text_embedding_config: dict, azure_ai_search_config: dict, index_name: str):
        """
        Initializes the KnowledgeBaseManager with the provided Azure OpenAI and Azure AI Search configurations.

        Args:
            azure_text_embedding_config (dict): Configuration dictionary for Azure OpenAI text embedding service.
                Example: {
                    "azure_deployment": "text-embedding-deployment",
                    "api_key": "your-azure-openai-api-key",
                    "endpoint": "https://api.openai.azure.com/",
                    "model": "text-embedding-model"
                }
            azure_ai_search_config (dict): Configuration dictionary for Azure Cognitive Search service.
                Example: {
                    "endpoint": "https://your-search-service.search.windows.net",
                    "api_key": "your-azure-search-api-key",
                }
        """

        # Define chunk size and overlap for splitting text
        chunk_size = 1024
        chunk_overlap = 500

        # Defines the instance of AzureOpenAIEmbedding class
        self.embeddings = AzureOpenAIEmbeddings(
            azure_deployment=azure_text_embedding_config["azure_deployment"],
            openai_api_key=azure_text_embedding_config["api_key"],
            azure_endpoint=azure_text_embedding_config["endpoint"],
            model=azure_text_embedding_config["model"],
            chunk_size=chunk_size,
        )

        # Defines instance of SearchIndexClient class
        self.search_index_client = SearchIndexClient(
                endpoint=azure_ai_search_config["endpoint"],
                credential=AzureKeyCredential(azure_ai_search_config["api_key"]),
            )

        # create SearchClient for search function
        self.search_client = SearchClient(
                endpoint=azure_ai_search_config["endpoint"],
                credential=AzureKeyCredential(azure_ai_search_config["api_key"]),
                index_name=index_name
            )
        
        # Find the dimension of the embedding model
        sample_text = "Embeddings dimension finder"
        embedding_vector = self.embeddings.embed_query(sample_text)
        self.embedding_dimension = len(embedding_vector)

        # Define instance of CharacterTextSplitter class with chunk size of 1500 and chunk overlap of 500
        self.text_splitter = CharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)

        self.index_name = index_name

    def create_index(self):
        """
        Creates or updates a search index with the provided index name.

        Returns:
            str: The name of the created or updated search index.

        Raises:
            Exception: If an error occurs during the creation or updating of the search index.
        """
        
        try:  
            # Defines the structure of the search index
            fields = [
                # Used for basic indexing
                SearchableField(
                    name="id",
                    type=SearchFieldDataType.String,
                    key=True,
                    filterable=True,
                    retrievable=True,
                    stored=True,
                    sortable=False,
                    facetable=False,
                    analyzer_name="keyword"
                ),
                SearchableField(
                    name="title",
                    type=SearchFieldDataType.String,
                    filterable=True,
                    sortable=True,
                ),
                # Used for complex search features
                SearchableField(
                    name="content",
                    type=SearchFieldDataType.String,
                    searchable=True,
                    filterable=False,
                    retrievable=True,
                    stored=True,
                    sortable=False,
                    facetable=False,
                ),
                # Used for complex search features and has more flexibility than SearchableField
                SearchField(
                    name="content_vector",
                    type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                    searchable=True,
                    vector_search_dimensions=self.embedding_dimension,
                    vector_search_profile_name="my-vector-config",
                ), 
            ]

            # Setting up vector search configuration
            vector_search = VectorSearch(
                profiles=[
                    VectorSearchProfile(
                        name="my-vector-config",
                        algorithm_configuration_name="my-algorithms-config",
                    )
                ],
                algorithms=[HnswAlgorithmConfiguration(name="my-algorithms-config")],
            )

            searchindex = SearchIndex(
                name=self.index_name, fields=fields, vector_search=vector_search
            )

            # Creates the new search index or updates it if it already exists
            self.search_index_client.create_or_update_index(index=searchindex)

            return self.index_name
        except Exception as e:
            return e

    def add_or_update_docs(self, documents):
        """
        Adds or updates documents in the knowledge base.
        This method processes a list of documents, determining whether each document
        needs to be added as a new entry or updated if it already exists. It splits
        the documents into smaller chunks, generates embeddings for each chunk, and
        then either updates the existing entries or adds new ones as necessary.
        Args:
            documents (list): A list of document objects to be added or updated. Each
                              document should have a 'metadata' attribute containing
                              a 'source' key.
        Returns:
            bool: True if the operation is successful, otherwise returns the exception.
        Raises:
            Exception: If an error occurs during the process, it prints the error message
                       and returns the exception.
        """
        

        # List to store all the docs that need to be added
        docs_to_add_final = []

        # List to store all the docs that need to be updated
        docs_to_update_final = []

        # Loop to separate the docs that need to be updated from the docs that need to be added
        for doc in documents:
            filename = Path(doc.metadata["source"]).name


            # check if document already exists
            search_results = list(
                self.search_client.search(filter=f"title eq '{filename}'")
            )

            split_docs = self.text_splitter.split_documents([doc])
            
            # logger.info(f"Results: {search_results}")
            if search_results:

                docs_to_update_id = [result["id"] for result in search_results]
                docs_to_update_page_content = [
                    sdoc.page_content for sdoc in split_docs
                ]  # ["Hello", "There"]
                docs_to_update_embeddings = self.embeddings.embed_documents(
                    docs_to_update_page_content
                )  # [[0.001,0.003], [0.002, 0.005]]
                num_existing_docs = len(search_results)

                    
                for i, sdoc in enumerate(split_docs[:num_existing_docs]):
                    docs_to_update_final.append(
                        {
                            "id": docs_to_update_id[i],
                            "content": sdoc.page_content,
                            "content_vector": docs_to_update_embeddings[i],
                            "title": filename,
                        }
                    )

                # if updated document requires more chunks of docs to be stored, add them
                if len(split_docs) > num_existing_docs:

                    for i, sdoc in enumerate(split_docs[num_existing_docs:]):

                        docs_to_add_final.append(
                            {
                                "id": str(uuid.uuid4()),
                                "content": sdoc.page_content,
                                "content_vector": docs_to_update_embeddings[i+num_existing_docs],
                                "title": filename,
                            }
                        )

                print(f"Updated {filename}!")
            else:
                docs_to_add_page_content = [
                    sdoc.page_content for sdoc in split_docs
                ]
                docs_to_add_embeddings = self.embeddings.embed_documents(
                    docs_to_add_page_content
                )

                for i, sdoc in enumerate(split_docs):
                    docs_to_add_final.append(
                        {
                            "id": str(uuid.uuid4()),
                            "content": sdoc.page_content,
                            "content_vector": docs_to_add_embeddings[i],
                            "title": filename,
                        }
                    )

                print(f"Added {filename}!")

        if docs_to_update_final:
            self.search_client.merge_documents(docs_to_update_final)

        if docs_to_add_final:
            self.search_client.upload_documents(docs_to_add_final)

        return True

    def add_or_update_from_strings(self, strings):
        """
        Add or update documents in the knowledge base from a list of strings.

        This method transforms the provided strings into document objects and
        then adds or updates these documents in the knowledge base.

        Args:
            strings (list of str): A list of strings to be transformed into documents
                                    and added or updated in the knowledge base.

        Returns:
            The result of the add_or_update_docs method, which typically includes
            information about the success or failure of the operation.
        """

        # Transform strings into documents
        documents = strings_to_documents(strings)

        return self.add_or_update_docs(documents)

    
    def fetch_and_index_cosmosdb_data(self, qna_manager:QnAManager):
        """
        Fetches data from Azure CosmosDB using the provided QnAManager, converts it to a string format,
        and indexes it into the knowledge base.

        Args:
            qna_manager (QnAManager): An instance of QnAManager used to fetch and generate QnA data.

        Returns:
            bool: True if data fetching and indexing is successful, False otherwise.

        Raises:
            Exception: If there is an error during the fetching or indexing process.
        """

        try:
            # Fetch all data from Azure CosmosDB
            qna_list_str = qna_manager.generate_qna_string()
            
            return self.add_or_update_from_strings(strings=[qna_list_str])

        except Exception as e:
            (f"Failed to index data: {e}")

            return False

    def delete_embeddings_function(self, fileName):
        """
        Deletes embeddings associated with a given file name from the search index.

        Args:
            fileName (str): The name of the file whose embeddings are to be deleted.
        Returns:
            bool: True if the embeddings were successfully deleted, False otherwise.
        Raises:
            Exception: If an error occurs during the deletion process, it will be caught and printed.
        """


        try:
            # Search for all the docs/chunks with that particular fileName
            search_result = self.search_index_client.search(filter=f"filename eq '{fileName}'")
            ids_to_delete = []
            for result in search_result:
                # Extract the doc's id
                print(result["id"])
                ids_to_delete.append({"id": result["id"]})

            if len(ids_to_delete) != 0:
                self.search_index_client.delete_documents(ids_to_delete)

            return True

        except Exception as e:
            print(f"An error occurred: {e}")
            return False

    def delete_index_function(self):
        """Deletes index associated with the given index name.

        Returns:
            bool: True if the index was successfully deleted, False otherwise.
        """

        self.search_index_client.delete_index(index=self.index_name)
        
        return True


    def similarity_search(self, query, top_k=5) -> SearchItemPaged[Dict]:
        """
        Performs a similarity search on the knowledge base using the provided query.

        Args:
            query (str): The query to search for in the knowledge base.
            top_k (int): The number of top results to return. Defaults to 5.

        Returns:
            list: A list of dictionaries containing the top k search results.
        """

        # Perform the search
        results = self.search_client.search(search_text=query, top=top_k)

        return results

    

